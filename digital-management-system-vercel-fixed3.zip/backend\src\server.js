const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST", "PUT", "DELETE"],
    credentials: true
  }
});

// 中间件
app.use(cors());
app.use(express.json({ charset: 'utf-8' }));
app.use(express.urlencoded({ extended: true, charset: 'utf-8' }));

// 提供静态文件
app.use(express.static(path.join(__dirname, '../dist')));

// 处理根路径请求
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});

// 处理展示页面请求
app.get('/display', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/display.html'));
});

// 初始数据 - 三组特定的数字序列
let numberGroups = [
  {
    id: 1,
    name: "《单一组》福彩合.80",
    numbers: "045.046.047.048.049.\n040.021.042.043.044.\n540.541.568.057.528.\n052.054.058.059.053."
  },
  {
    id: 2,
    name: "《五单一组》福彩合.110",
    numbers: "041.042.043.044.045\n054.052.053.050.051."
  },
  {
    id: 3,
    name: "《十单一组》福彩合.110",
    numbers: "045.054.041.043.053"
  }
];

// 获取所有数字组
app.get('/api/numbers', (req, res) => {
  res.json(numberGroups);
});

// 添加新数字组
app.post('/api/numbers', (req, res) => {
  const { id, name, numbers } = req.body;
  
  // 检查ID是否已存在
  const existingGroup = numberGroups.find(group => group.id === id);
  if (existingGroup) {
    return res.status(400).json({ message: 'ID已存在' });
  }
  
  // 添加新组
  const newGroup = { id, name, numbers };
  numberGroups.push(newGroup);
  
  // 通知所有连接的客户端数据已更新
  io.emit('numbersUpdated', numberGroups);
  
  res.status(201).json({ message: '添加成功', data: newGroup });
});

// 更新特定数字组
app.put('/api/numbers/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { name, numbers } = req.body;
  
  const groupIndex = numberGroups.findIndex(group => group.id === id);
  if (groupIndex !== -1) {
    // 更新标题和数字内容
    if (name !== undefined) {
      numberGroups[groupIndex].name = name;
    }
    if (numbers !== undefined) {
      numberGroups[groupIndex].numbers = numbers;
    }
    // 通知所有连接的客户端数据已更新
    io.emit('numbersUpdated', numberGroups);
    res.json({ message: '更新成功', data: numberGroups[groupIndex] });
  } else {
    res.status(404).json({ message: '未找到指定的数字组' });
  }
});

// 删除特定数字组
app.delete('/api/numbers/:id', (req, res) => {
  const id = parseInt(req.params.id);
  
  const groupIndex = numberGroups.findIndex(group => group.id === id);
  if (groupIndex !== -1) {
    // 删除组
    const deletedGroup = numberGroups.splice(groupIndex, 1)[0];
    
    // 通知所有连接的客户端数据已更新
    io.emit('numbersUpdated', numberGroups);
    
    res.json({ message: '删除成功', data: deletedGroup });
  } else {
    res.status(404).json({ message: '未找到指定的数字组' });
  }
});

// WebSocket连接处理
io.on('connection', (socket) => {
  console.log('新客户端已连接');
  
  // 发送初始数据
  socket.emit('initialData', numberGroups);
  
  socket.on('disconnect', () => {
    console.log('客户端已断开连接');
  });
});

// 添加健康检查端点
app.get('/health', (req, res) => {
  res.json({ status: 'OK', timestamp: new Date().toISOString() });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`服务器运行在端口 ${PORT}`);
});