# 数字管理系统

一个实时数字展示和管理系统，支持在线编辑和实时展示。

## 功能特性

- 实时数据展示
- 在线编辑管理
- WebSocket实时同步
- 响应式设计

## 部署到Vercel

1. 将代码推送到GitHub仓库
2. 在Vercel中导入项目
3. 配置环境变量（如果需要）
4. 部署完成

## 本地开发

```bash
npm install
npm run dev
```

访问:
- 管理页面: http://localhost:3000
- 展示页面: http://localhost:3000/display

## API接口

- `GET /api/numbers` - 获取所有数字组
- `POST /api/numbers` - 添加数字组
- `PUT /api/numbers/:id` - 更新数字组
- `DELETE /api/numbers/:id` - 删除数字组

## WebSocket事件

- `initialData` - 初始数据
- `numbersUpdated` - 数据更新